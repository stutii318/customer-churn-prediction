# ============================================================
# Phase 3 - XGBoost Model + MLflow Tracking
# Run this file in Jupyter as 02_model.ipynb
# OR run directly: python 02_model.py
# ============================================================

# Cell 1 - Imports
import pandas as pd
import numpy as np
import mlflow
import mlflow.sklearn
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, roc_auc_score,
                             classification_report, confusion_matrix)
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
import warnings
warnings.filterwarnings('ignore')

print("All imports OK")

# Cell 2 - Load processed data
df = pd.read_csv('../data/processed/churn_features.csv')
print("Shape:", df.shape)

bool_cols = df.select_dtypes(include='bool').columns
df[bool_cols] = df[bool_cols].astype(int)

X = df.drop('Exited', axis=1)
y = df['Exited']

print("Features:", X.shape[1])
print("Churn rate:", y.mean().round(3))

# Cell 3 - Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print("Train size:", X_train.shape)
print("Test size:", X_test.shape)

# Cell 4 - Train with MLflow tracking
mlflow.set_experiment("churn-prediction")

with mlflow.start_run(run_name="xgboost-baseline"):

    params = {
        "n_estimators": 300,
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "scale_pos_weight": 4,
        "random_state": 42
    }

    model = xgb.XGBClassifier(**params, eval_metric='logloss')
    model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              verbose=False)

    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)

    mlflow.log_params(params)
    mlflow.log_metric("accuracy", acc)
    mlflow.log_metric("roc_auc", auc)
    mlflow.sklearn.log_model(model, "model")

    print(f"Accuracy : {acc:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Retained', 'Churned']))

# Cell 5 - Confusion matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Retained', 'Churned'],
            yticklabels=['Retained', 'Churned'])
plt.title('Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.tight_layout()
plt.savefig('../reports/confusion_matrix.png', dpi=150)
plt.show()
print("Confusion matrix saved")

# Cell 6 - Feature importance
feat_imp = pd.DataFrame({
    'feature': X.columns,
    'importance': model.feature_importances_
}).sort_values('importance', ascending=False).head(15)

plt.figure(figsize=(10, 6))
sns.barplot(data=feat_imp, x='importance', y='feature', color='#2196F3')
plt.title('Top 15 Most Important Features')
plt.tight_layout()
plt.savefig('../reports/feature_importance.png', dpi=150)
plt.show()
print("Feature importance saved")

# Cell 7 - Save model
with open('../models/xgb_churn_model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("Model saved to models/xgb_churn_model.pkl")
