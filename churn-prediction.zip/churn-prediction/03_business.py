# ============================================================
# Phase 4 - Business Layer: CLV Segments + Interventions
# Run: python 03_business.py
# ============================================================

import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ── Load model and data ──────────────────────────────────────
with open('../models/xgb_churn_model.pkl', 'rb') as f:
    model = pickle.load(f)

df_raw = pd.read_csv('../data/raw/Churn_Modelling.csv')
df_feat = pd.read_csv('../data/processed/churn_features.csv')

bool_cols = df_feat.select_dtypes(include='bool').columns
df_feat[bool_cols] = df_feat[bool_cols].astype(int)

X = df_feat.drop('Exited', axis=1)
y = df_feat['Exited']

print("Data loaded OK")

# ── Churn probability scores ─────────────────────────────────
churn_prob = model.predict_proba(X)[:, 1]
df_raw = df_raw.copy()
df_raw['ChurnProbability'] = churn_prob
df_raw['ChurnPredicted']   = (churn_prob >= 0.5).astype(int)

# ── CLV (Customer Lifetime Value) ────────────────────────────
# Simple CLV proxy: Balance * Tenure * IsActiveMember
df_raw['CLV'] = (
    df_raw['Balance'] * 0.05 * df_raw['Tenure'] *
    (1 + df_raw['IsActiveMember']) *
    (1 + df_raw['NumOfProducts'] * 0.2)
).round(2)

# ── Risk Segments ────────────────────────────────────────────
def risk_segment(prob):
    if prob >= 0.75:
        return 'Critical'
    elif prob >= 0.50:
        return 'High'
    elif prob >= 0.25:
        return 'Medium'
    else:
        return 'Low'

df_raw['RiskSegment'] = df_raw['ChurnProbability'].apply(risk_segment)

# ── Intervention Recommendations ─────────────────────────────
def recommend_action(row):
    if row['RiskSegment'] == 'Critical' and row['CLV'] > 5000:
        return 'Immediate retention call + premium offer'
    elif row['RiskSegment'] == 'Critical':
        return 'Retention call + discount offer'
    elif row['RiskSegment'] == 'High' and row['IsActiveMember'] == 0:
        return 'Re-engagement email campaign'
    elif row['RiskSegment'] == 'High':
        return 'Loyalty reward offer'
    elif row['RiskSegment'] == 'Medium':
        return 'Personalized product recommendation'
    else:
        return 'Standard nurture campaign'

df_raw['RecommendedAction'] = df_raw.apply(recommend_action, axis=1)

# ── Revenue at Risk ──────────────────────────────────────────
at_risk = df_raw[df_raw['RiskSegment'].isin(['Critical', 'High'])]
revenue_at_risk = at_risk['CLV'].sum()
print(f"\nCustomers at High/Critical risk : {len(at_risk)}")
print(f"Total CLV at risk               : ${revenue_at_risk:,.0f}")

# ── Segment summary ──────────────────────────────────────────
segment_summary = df_raw.groupby('RiskSegment').agg(
    CustomerCount=('CustomerId', 'count'),
    AvgChurnProb=('ChurnProbability', 'mean'),
    TotalCLV=('CLV', 'sum'),
    AvgBalance=('Balance', 'mean')
).round(2).reset_index()

segment_order = ['Critical', 'High', 'Medium', 'Low']
segment_summary['RiskSegment'] = pd.Categorical(
    segment_summary['RiskSegment'], categories=segment_order, ordered=True
)
segment_summary = segment_summary.sort_values('RiskSegment')
print("\nSegment Summary:")
print(segment_summary.to_string(index=False))

# ── Charts ───────────────────────────────────────────────────
colors = {'Critical': '#F44336', 'High': '#FF9800',
          'Medium': '#FFC107', 'Low': '#4CAF50'}

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Customer Churn - Business Intelligence Dashboard', fontsize=14, fontweight='bold')

# 1. Customers by risk segment
seg = segment_summary.set_index('RiskSegment')
seg['CustomerCount'].plot(kind='bar', ax=axes[0][0],
    color=[colors[s] for s in seg.index], edgecolor='white')
axes[0][0].set_title('Customers by Risk Segment')
axes[0][0].set_xlabel('')
axes[0][0].set_xticklabels(seg.index, rotation=0)

# 2. CLV at risk by segment
seg['TotalCLV'].plot(kind='bar', ax=axes[0][1],
    color=[colors[s] for s in seg.index], edgecolor='white')
axes[0][1].set_title('Total CLV at Risk by Segment')
axes[0][1].set_xlabel('')
axes[0][1].set_xticklabels(seg.index, rotation=0)

# 3. Churn probability distribution
axes[1][0].hist(df_raw['ChurnProbability'], bins=40, color='#2196F3', edgecolor='white')
axes[1][0].axvline(0.5, color='red', linestyle='--', label='Decision boundary')
axes[1][0].set_title('Churn Probability Distribution')
axes[1][0].set_xlabel('Churn Probability')
axes[1][0].legend()

# 4. Recommended actions breakdown
action_counts = df_raw['RecommendedAction'].value_counts()
action_counts.plot(kind='barh', ax=axes[1][1], color='#9C27B0')
axes[1][1].set_title('Recommended Interventions')
axes[1][1].set_xlabel('Number of Customers')

plt.tight_layout()
plt.savefig('../reports/business_dashboard.png', dpi=150)
plt.show()
print("\nDashboard saved to reports/business_dashboard.png")

# ── Export for Power BI ──────────────────────────────────────
export_cols = ['CustomerId', 'Surname', 'Geography', 'Gender', 'Age',
               'Tenure', 'Balance', 'NumOfProducts', 'IsActiveMember',
               'EstimatedSalary', 'Exited', 'ChurnProbability',
               'ChurnPredicted', 'CLV', 'RiskSegment', 'RecommendedAction']

df_export = df_raw[export_cols].copy()
df_export.to_csv('../data/processed/churn_scored.csv', index=False)
print("Power BI export saved to data/processed/churn_scored.csv")
print(f"\nTotal customers exported : {len(df_export)}")
print(f"Columns                  : {list(df_export.columns)}")
