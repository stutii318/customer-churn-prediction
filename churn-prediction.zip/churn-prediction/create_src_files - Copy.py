# ============================================================
# src/preprocess.py
# ============================================================
preprocess = '''
import pandas as pd
import numpy as np

def load_raw(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.drop(["RowNumber", "CustomerId", "Surname"], axis=1, inplace=True)
    return df

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["BalanceSalaryRatio"]  = df["Balance"] / (df["EstimatedSalary"] + 1)
    df["TenureByAge"]         = df["Tenure"] / df["Age"]
    df["CreditScoreCategory"] = pd.cut(df["CreditScore"],
                                    bins=[0,580,670,740,800,851],
                                    labels=["Poor","Fair","Good","VeryGood","Exceptional"])
    df["AgeGroup"]            = pd.cut(df["Age"],
                                    bins=[0,30,45,60,100],
                                    labels=["Young","MidAge","Senior","Elder"])
    df["IsHighValueCustomer"] = (
        (df["Balance"] > df["Balance"].quantile(0.75)) &
        (df["NumOfProducts"] >= 2)
    ).astype(int)
    df = pd.get_dummies(df, columns=["Geography","Gender","CreditScoreCategory","AgeGroup"])
    bool_cols = df.select_dtypes(include="bool").columns
    df[bool_cols] = df[bool_cols].astype(int)
    return df

def get_X_y(df: pd.DataFrame):
    X = df.drop("Exited", axis=1)
    y = df["Exited"]
    return X, y
'''

# ============================================================
# src/train.py
# ============================================================
train = '''
import mlflow
import mlflow.sklearn
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
import pickle

def train_model(X, y, params: dict = None):
    if params is None:
        params = {
            "n_estimators": 300,
            "max_depth": 6,
            "learning_rate": 0.05,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "scale_pos_weight": 4,
            "random_state": 42
        }

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    mlflow.set_experiment("churn-prediction")
    with mlflow.start_run(run_name="xgboost"):
        model = xgb.XGBClassifier(**params, eval_metric="logloss")
        model.fit(X_train, y_train,
                  eval_set=[(X_test, y_test)],
                  verbose=False)

        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]

        acc = accuracy_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_prob)

        mlflow.log_params(params)
        mlflow.log_metric("accuracy", acc)
        mlflow.log_metric("roc_auc", auc)
        mlflow.sklearn.log_model(model, "model")

        print(f"Accuracy : {acc:.4f}")
        print(f"ROC-AUC  : {auc:.4f}")
        print(classification_report(y_test, y_pred, target_names=["Retained","Churned"]))

    return model

def save_model(model, path: str):
    with open(path, "wb") as f:
        pickle.dump(model, f)
    print(f"Model saved to {path}")
'''

# ============================================================
# src/predict.py
# ============================================================
predict = '''
import pickle
import pandas as pd
import numpy as np

def load_model(path: str):
    with open(path, "rb") as f:
        return pickle.load(f)

def predict_churn(model, X: pd.DataFrame) -> pd.DataFrame:
    churn_prob = model.predict_proba(X)[:, 1]
    churn_pred = (churn_prob >= 0.5).astype(int)
    return pd.DataFrame({"ChurnProbability": churn_prob, "ChurnPredicted": churn_pred})

def get_risk_segment(prob: float) -> str:
    if prob >= 0.75:
        return "Critical"
    elif prob >= 0.50:
        return "High"
    elif prob >= 0.25:
        return "Medium"
    return "Low"

def calculate_clv(df: pd.DataFrame) -> pd.Series:
    return (
        df["Balance"] * 0.05 * df["Tenure"] *
        (1 + df["IsActiveMember"]) *
        (1 + df["NumOfProducts"] * 0.2)
    ).round(2)

def recommend_action(row) -> str:
    if row["RiskSegment"] == "Critical" and row["CLV"] > 5000:
        return "Immediate retention call + premium offer"
    elif row["RiskSegment"] == "Critical":
        return "Retention call + discount offer"
    elif row["RiskSegment"] == "High" and row["IsActiveMember"] == 0:
        return "Re-engagement email campaign"
    elif row["RiskSegment"] == "High":
        return "Loyalty reward offer"
    elif row["RiskSegment"] == "Medium":
        return "Personalized product recommendation"
    return "Standard nurture campaign"
'''

# ============================================================
# src/app.py - FastAPI inference endpoint
# ============================================================
app = '''
from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import pandas as pd
import sys
sys.path.append("..")
from src.predict import predict_churn, get_risk_segment, calculate_clv, recommend_action

app = FastAPI(title="Churn Prediction API", version="1.0")

with open("models/xgb_churn_model.pkl", "rb") as f:
    model = pickle.load(f)

class CustomerInput(BaseModel):
    CreditScore: float
    Age: float
    Tenure: float
    Balance: float
    NumOfProducts: int
    HasCrCard: int
    IsActiveMember: int
    EstimatedSalary: float
    Geography_France: int
    Geography_Germany: int
    Geography_Spain: int
    Gender_Female: int
    Gender_Male: int

@app.get("/")
def root():
    return {"message": "Churn Prediction API is running"}

@app.post("/predict")
def predict(customer: CustomerInput):
    data = pd.DataFrame([customer.dict()])
    proba = model.predict_proba(data)[0][1]
    segment = get_risk_segment(proba)
    return {
        "churn_probability": round(float(proba), 4),
        "churn_predicted": int(proba >= 0.5),
        "risk_segment": segment,
    }

@app.get("/health")
def health():
    return {"status": "healthy"}
'''

# Write all files
with open("C:/Users/hp/churn-prediction/src/preprocess.py", "w") as f:
    f.write(preprocess.strip())

with open("C:/Users/hp/churn-prediction/src/train.py", "w") as f:
    f.write(train.strip())

with open("C:/Users/hp/churn-prediction/src/predict.py", "w") as f:
    f.write(predict.strip())

with open("C:/Users/hp/churn-prediction/src/app.py", "w") as f:
    f.write(app.strip())

print("All src/ files created successfully!")
print("  - src/preprocess.py")
print("  - src/train.py")
print("  - src/predict.py")
print("  - src/app.py")
