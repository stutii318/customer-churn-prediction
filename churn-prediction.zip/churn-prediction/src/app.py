from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import pandas as pd
import sys
sys.path.append("..")
from src.predict import predict_churn, get_risk_segment, calculate_clv, recommend_action

app = FastAPI(title="Churn Prediction API", version="1.0")

with open("models/xgb_churn_model.pkl", "rb") as f:
    model = pickle.load(f)

class CustomerInput(BaseModel):
    CreditScore: float
    Age: float
    Tenure: float
    Balance: float
    NumOfProducts: int
    HasCrCard: int
    IsActiveMember: int
    EstimatedSalary: float
    Geography_France: int
    Geography_Germany: int
    Geography_Spain: int
    Gender_Female: int
    Gender_Male: int

@app.get("/")
def root():
    return {"message": "Churn Prediction API is running"}

@app.post("/predict")
def predict(customer: CustomerInput):
    data = pd.DataFrame([customer.dict()])
    proba = model.predict_proba(data)[0][1]
    segment = get_risk_segment(proba)
    return {
        "churn_probability": round(float(proba), 4),
        "churn_predicted": int(proba >= 0.5),
        "risk_segment": segment,
    }

@app.get("/health")
def health():
    return {"status": "healthy"}