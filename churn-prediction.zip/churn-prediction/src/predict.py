import pickle
import pandas as pd
import numpy as np

def load_model(path: str):
    with open(path, "rb") as f:
        return pickle.load(f)

def predict_churn(model, X: pd.DataFrame) -> pd.DataFrame:
    churn_prob = model.predict_proba(X)[:, 1]
    churn_pred = (churn_prob >= 0.5).astype(int)
    return pd.DataFrame({"ChurnProbability": churn_prob, "ChurnPredicted": churn_pred})

def get_risk_segment(prob: float) -> str:
    if prob >= 0.75:
        return "Critical"
    elif prob >= 0.50:
        return "High"
    elif prob >= 0.25:
        return "Medium"
    return "Low"

def calculate_clv(df: pd.DataFrame) -> pd.Series:
    return (
        df["Balance"] * 0.05 * df["Tenure"] *
        (1 + df["IsActiveMember"]) *
        (1 + df["NumOfProducts"] * 0.2)
    ).round(2)

def recommend_action(row) -> str:
    if row["RiskSegment"] == "Critical" and row["CLV"] > 5000:
        return "Immediate retention call + premium offer"
    elif row["RiskSegment"] == "Critical":
        return "Retention call + discount offer"
    elif row["RiskSegment"] == "High" and row["IsActiveMember"] == 0:
        return "Re-engagement email campaign"
    elif row["RiskSegment"] == "High":
        return "Loyalty reward offer"
    elif row["RiskSegment"] == "Medium":
        return "Personalized product recommendation"
    return "Standard nurture campaign"