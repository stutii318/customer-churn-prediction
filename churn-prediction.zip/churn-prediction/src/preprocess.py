import pandas as pd
import numpy as np

def load_raw(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.drop(["RowNumber", "CustomerId", "Surname"], axis=1, inplace=True)
    return df

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["BalanceSalaryRatio"]  = df["Balance"] / (df["EstimatedSalary"] + 1)
    df["TenureByAge"]         = df["Tenure"] / df["Age"]
    df["CreditScoreCategory"] = pd.cut(df["CreditScore"],
                                    bins=[0,580,670,740,800,851],
                                    labels=["Poor","Fair","Good","VeryGood","Exceptional"])
    df["AgeGroup"]            = pd.cut(df["Age"],
                                    bins=[0,30,45,60,100],
                                    labels=["Young","MidAge","Senior","Elder"])
    df["IsHighValueCustomer"] = (
        (df["Balance"] > df["Balance"].quantile(0.75)) &
        (df["NumOfProducts"] >= 2)
    ).astype(int)
    df = pd.get_dummies(df, columns=["Geography","Gender","CreditScoreCategory","AgeGroup"])
    bool_cols = df.select_dtypes(include="bool").columns
    df[bool_cols] = df[bool_cols].astype(int)
    return df

def get_X_y(df: pd.DataFrame):
    X = df.drop("Exited", axis=1)
    y = df["Exited"]
    return X, y